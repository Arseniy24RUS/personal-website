# sitkovsky.rf — GitHub Pages (static)

This repository is a build-free static website (HTML/CSS/JS), designed for GitHub Pages.

## What is implemented now
- Home page (`index.html`) with RU/EN switch (`?lang=ru|en`)
- Publications page (`publications.html`) loaded from ORCID Public API
- Placeholders ("Coming soon") for other sections
- Auto-refresh pipeline via GitHub Actions:
  - `scripts/fetch_orcid.py` → `data/orcid-works.json`
  - `scripts/fetch_github.py` → `data/github.json`

## How to publish on GitHub Pages
1. Create a public repo (e.g., `sitkovsky-rf`) and push files.
2. In **Settings → Pages** choose:
   - Source: **Deploy from a branch**
   - Branch: `main` / root (`/`)
3. Wait until GitHub Pages builds the site.

## Custom domain (IDN)
- Domain: `ситковский.рф`
- Punycode for GitHub settings: `xn--b1albecb0aveg.xn--p1ai`

Create DNS records at your registrar:
- For the apex domain: add `A` records to GitHub Pages IPs (see GitHub Docs).
- Optionally add `CNAME` for `www` → `<username>.github.io`.

## Manual metrics
Update `data/metrics.manual.json` when RSCI/Scopus/WoS numbers change.
Last preset date: 2026-02-01.

## Notes
- ORCID list is complete only for works that are public in ORCID.
- For Scopus/WoS fully automated metrics you typically need API keys/subscriptions.
