#!/usr/bin/env python3
import json, os, sys, datetime, requests

ORCID = os.environ.get("ORCID_ID", "0000-0002-8725-6580")
OUT = os.environ.get("ORCID_OUT", "data/orcid-works.json")
API = f"https://pub.orcid.org/v3.0/{ORCID}/works"

def main():
    r = requests.get(API, headers={"Accept":"application/json"}, timeout=30)
    r.raise_for_status()
    raw = r.json()

    items = []
    for group in raw.get("group", []):
        for ws in group.get("work-summary", []):
            title = (((ws.get("title") or {}).get("title") or {}).get("value")) or ""
            pdate = ws.get("publication-date") or {}
            year = (pdate.get("year") or {}).get("value")
            month = (pdate.get("month") or {}).get("value")
            day = (pdate.get("day") or {}).get("value")
            wtype = ws.get("type")
            url = (ws.get("url") or {}).get("value")
            put_code = ws.get("put-code")
            doi = None

            # Try to extract DOI from external-ids in the summary (if present)
            ext = (ws.get("external-ids") or {}).get("external-id") or []
            for e in ext:
                if (e.get("external-id-type") or "").lower() == "doi":
                    doi = (e.get("external-id-value") or "").strip() or doi

            items.append({
                "title": title,
                "year": year,
                "month": month,
                "day": day,
                "type": wtype,
                "url": url,
                "put_code": put_code,
                "doi": doi,
            })

    payload = {
        "generated_at": datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "orcid": ORCID,
        "items": items,
        "count": len(items),
    }

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
