#!/usr/bin/env python3
import json, os, datetime, requests

USER = os.environ.get("GITHUB_USER", "Arseniy24RUS")
OUT = os.environ.get("GITHUB_OUT", "data/github.json")
TOKEN = os.environ.get("GITHUB_TOKEN")

def get(url):
    headers = {"Accept":"application/vnd.github+json"}
    if TOKEN:
        headers["Authorization"] = f"Bearer {TOKEN}"
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    return r

def main():
    user = get(f"https://api.github.com/users/{USER}").json()

    # Total stars across public repos
    stars = 0
    forks = 0
    page = 1
    while True:
        r = get(f"https://api.github.com/users/{USER}/repos?per_page=100&page={page}&type=owner&sort=updated")
        repos = r.json()
        if not repos:
            break
        for repo in repos:
            stars += int(repo.get("stargazers_count") or 0)
            forks += int(repo.get("forks_count") or 0)
        # Link header paging
        link = r.headers.get("Link", "")
        if 'rel="next"' not in link:
            break
        page += 1

    payload = dict(user)
    payload["total_stars"] = stars
    payload["total_forks"] = forks
    payload["generated_at"] = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()
