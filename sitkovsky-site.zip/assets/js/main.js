/* sitkovsky.rf – lightweight static site runtime (no build step) */

const DEFAULT_LANG = "ru";
const LANGS = ["ru","en"];

function getQueryParam(name){
  const u = new URL(window.location.href);
  return u.searchParams.get(name);
}

function setQueryParam(name, value){
  const u = new URL(window.location.href);
  if(value === null || value === undefined){ u.searchParams.delete(name); }
  else { u.searchParams.set(name, value); }
  history.replaceState({}, "", u.toString());
}

function detectLang(){
  const qp = getQueryParam("lang");
  if (LANGS.includes(qp)) return qp;

  const stored = localStorage.getItem("lang");
  if (LANGS.includes(stored)) return stored;

  const n = (navigator.language || "").toLowerCase();
  if (n.startsWith("ru")) return "ru";
  return DEFAULT_LANG;
}

async function loadJSON(path){
  const r = await fetch(path, {cache: "no-store"});
  if(!r.ok) throw new Error(`Failed to load ${path}: ${r.status}`);
  return await r.json();
}

function applyI18n(dict){
  document.documentElement.setAttribute("lang", dict.__lang || "ru");

  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key = el.getAttribute("data-i18n");
    if(dict[key] !== undefined){
      el.textContent = dict[key];
    }
  });

  document.querySelectorAll("[data-i18n-html]").forEach(el=>{
    const key = el.getAttribute("data-i18n-html");
    if(dict[key] !== undefined){
      el.innerHTML = dict[key];
    }
  });

  document.querySelectorAll("[data-i18n-attr]").forEach(el=>{
    const spec = el.getAttribute("data-i18n-attr");
    // format: attr:key
    const [attr, key] = spec.split(":");
    if(attr && key && dict[key] !== undefined){
      el.setAttribute(attr, dict[key]);
    }
  });
}

function markActiveNav(){
  const path = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll(".nav a").forEach(a=>{
    const href = (a.getAttribute("href")||"").split("?")[0].split("#")[0].toLowerCase();
    const page = href.split("/").pop();
    if(page === path) a.classList.add("active");
  });
}

function wireComingSoon(langDict){
  const modal = document.getElementById("comingSoonModal");
  const title = document.getElementById("comingSoonTitle");
  const body = document.getElementById("comingSoonBody");
  const closeBtn = document.getElementById("comingSoonClose");

  if(!modal) return;

  document.querySelectorAll("[data-coming-soon]").forEach(btn=>{
    btn.addEventListener("click", (e)=>{
      e.preventDefault();
      title.textContent = langDict["coming_soon_title"] || "В разработке";
      body.textContent = langDict["coming_soon_body"] || "Раздел будет добавлен позже.";
      modal.classList.add("show");
    });
  });

  const close = ()=> modal.classList.remove("show");
  closeBtn?.addEventListener("click", close);
  modal.addEventListener("click", (e)=>{ if(e.target === modal) close(); });
}

async function hydrateHome(lang, dict){
  // Load manual metrics
  try{
    const manual = await loadJSON("data/metrics.manual.json");
    const el = (id)=>document.getElementById(id);
    if(el("metric_rinc_h")) el("metric_rinc_h").textContent = manual?.rinc?.h_index ?? "—";
    if(el("metric_scopus_h")) el("metric_scopus_h").textContent = manual?.scopus?.h_index ?? "—";
    if(el("metric_wos_h")) el("metric_wos_h").textContent = manual?.wos?.h_index ?? "—";
    if(el("metric_manual_updated")) el("metric_manual_updated").textContent = manual?.updated_at ?? "—";

    // Identifiers
    if(el("id_rinc")) el("id_rinc").innerHTML = `<span class="key">RSCI:</span> AuthorID ${manual?.rinc?.authorid ?? ""} · SPIN ${manual?.rinc?.spin ?? ""}`;
    if(el("id_orcid")) el("id_orcid").innerHTML = `<span class="key">ORCID:</span> ${manual?.orcid ?? ""}`;
    if(el("id_wos")) el("id_wos").innerHTML = `<span class="key">WoS:</span> ResearcherID ${manual?.wos?.researcherid ?? ""}`;
    if(el("id_scopus")) el("id_scopus").innerHTML = `<span class="key">Scopus:</span> Author ID ${manual?.scopus?.authorid ?? ""}`;

    // Links
    const setHref = (id, href)=>{ const a = document.getElementById(id); if(a && href) a.href = href; };
    // NOTE: ORCID & GitHub links are stable; RSCI/Scopus/WoS links are set if provided
    setHref("link_orcid", manual?.orcid ? `https://orcid.org/${manual.orcid}` : null);
    setHref("link_github", manual?.github?.username ? `https://github.com/${manual.github.username}` : null);
  }catch(err){
    console.warn(err);
  }

  // GitHub stats (cached or live)
  try{
    let gh = null;
    try{
      gh = await loadJSON("data/github.json");
    }catch(_){
      // fallback to live
      const u = "https://api.github.com/users/Arseniy24RUS";
      const r = await fetch(u, {headers: {"Accept":"application/vnd.github+json"}});
      if(r.ok) gh = await r.json();
    }
    if(gh){
      const el = (id)=>document.getElementById(id);
      if(el("gh_followers")) el("gh_followers").textContent = gh.followers ?? "—";
      if(el("gh_repos")) el("gh_repos").textContent = gh.public_repos ?? "—";
      if(el("gh_stars") && gh.total_stars !== undefined) el("gh_stars").textContent = gh.total_stars;
      if(el("gh_updated")) el("gh_updated").textContent = gh.generated_at ?? (gh.updated_at ?? "—");
    }
  }catch(err){
    console.warn(err);
  }

  // ORCID works quick stats
  try{
    let ow = null;
    try{
      ow = await loadJSON("data/orcid-works.json");
    }catch(_){
      // fallback to live
      const orcid = "0000-0002-8725-6580";
      const r = await fetch(`https://pub.orcid.org/v3.0/${orcid}/works`, {headers: {"Accept":"application/json"}});
      if(r.ok) ow = { generated_at: null, items: (await r.json()).group || [] };
    }
    if(ow){
      const count = (ow.items || []).length;
      const el = (id)=>document.getElementById(id);
      if(el("orcid_works_count")) el("orcid_works_count").textContent = count || "—";
      if(el("orcid_updated")) el("orcid_updated").textContent = ow.generated_at ?? "—";
    }
  }catch(err){
    console.warn(err);
  }
}

async function hydratePublications(lang, dict){
  const root = document.getElementById("pubRoot");
  if(!root) return;

  const input = document.getElementById("pubQuery");
  const yearSel = document.getElementById("pubYear");
  const counter = document.getElementById("pubCounter");

  let data = null;

  async function load(){
    try{
      data = await loadJSON("data/orcid-works.json");
    }catch(err){
      // fallback to live
      const orcid = "0000-0002-8725-6580";
      const r = await fetch(`https://pub.orcid.org/v3.0/${orcid}/works`, {headers: {"Accept":"application/json"}});
      if(!r.ok) throw err;
      const raw = await r.json();
      // minimal parse
      const items = [];
      for(const g of (raw.group || [])){
        for(const ws of (g["work-summary"] || [])){
          items.push({
            title: ws?.title?.title?.value || "",
            year: ws?.["publication-date"]?.year?.value || null,
            month: ws?.["publication-date"]?.month?.value || null,
            day: ws?.["publication-date"]?.day?.value || null,
            type: ws?.type || null,
            url: ws?.url?.value || null,
            put_code: ws?.["put-code"] || null,
            doi: null
          });
        }
      }
      data = {generated_at: null, items};
    }
  }

  function norm(s){ return (s||"").toString().toLowerCase(); }

  function render(){
    const q = norm(input?.value);
    const y = yearSel?.value || "";

    let items = (data?.items || []).slice();

    if(y){
      items = items.filter(it => (it.year || "") === y);
    }
    if(q){
      items = items.filter(it => norm(it.title).includes(q) || norm(it.doi).includes(q) || norm(it.type).includes(q));
    }

    // sort by date desc (year, month, day); nulls last
    items.sort((a,b)=>{
      const ay = parseInt(a.year||"0",10), by = parseInt(b.year||"0",10);
      if(ay !== by) return by - ay;
      const am = parseInt(a.month||"0",10), bm = parseInt(b.month||"0",10);
      if(am !== bm) return bm - am;
      const ad = parseInt(a.day||"0",10), bd = parseInt(b.day||"0",10);
      return bd - ad;
    });

    // counter
    if(counter) counter.textContent = items.length.toString();

    // render rows
    const tbody = document.getElementById("pubBody");
    if(!tbody) return;
    tbody.innerHTML = "";

    for(const it of items){
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      const ymd = [it.year, it.month, it.day].filter(Boolean).join("-");
      const metaParts = [];
      if(ymd) metaParts.push(ymd);
      if(it.type) metaParts.push(it.type);
      const meta = metaParts.join(" · ");

      const links = [];
      if(it.doi) links.push({label: "DOI", href: `https://doi.org/${it.doi}`});
      if(it.url) links.push({label: "URL", href: it.url});

      td.innerHTML = `
        <div class="pub">
          <div class="title">${escapeHtml(it.title || "—")}</div>
          <div class="meta">${escapeHtml(meta)}</div>
          <div class="links">${links.map(l=>`<a href="${l.href}" target="_blank" rel="noopener noreferrer">${l.label}</a>`).join("")}</div>
        </div>
      `;
      tr.appendChild(td);
      tbody.appendChild(tr);
    }
  }

  function escapeHtml(str){
    return (str||"").replace(/[&<>"']/g, (m)=>({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[m]));
  }

  await load();

  // fill year selector
  const years = Array.from(new Set((data?.items||[]).map(it=>it.year).filter(Boolean))).sort((a,b)=>parseInt(b,10)-parseInt(a,10));
  if(yearSel){
    yearSel.innerHTML = `<option value="">${dict["pub_all_years"] || "Все годы"}</option>` + years.map(y=>`<option value="${y}">${y}</option>`).join("");
  }

  // wire events
  input?.addEventListener("input", render);
  yearSel?.addEventListener("change", render);

  render();
}

async function init(){
  const lang = detectLang();
  localStorage.setItem("lang", lang);
  setQueryParam("lang", lang);

  let dict = {};
  try{
    dict = await loadJSON(`i18n/${lang}.json`);
  }catch(err){
    console.warn(err);
  }
  dict.__lang = lang;

  applyI18n(dict);
  markActiveNav();
  wireComingSoon(dict);

  // language buttons
  document.querySelectorAll("[data-set-lang]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const l = btn.getAttribute("data-set-lang");
      if(LANGS.includes(l)){
        localStorage.setItem("lang", l);
        setQueryParam("lang", l);
        location.reload();
      }
    });
  });

  // page-specific hydration
  if(document.body.dataset.page === "home") await hydrateHome(lang, dict);
  if(document.body.dataset.page === "publications") await hydratePublications(lang, dict);
}

document.addEventListener("DOMContentLoaded", init);
